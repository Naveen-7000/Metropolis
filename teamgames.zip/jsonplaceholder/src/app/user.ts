import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';

export interface User {
  id?: number;
  name: string;
  email: string;
  phone: string;
}

@Injectable({ providedIn: 'root' })
export class UserService {
  private apiUrl = 'https://jsonplaceholder.typicode.com/users';
  private users$ = new BehaviorSubject<User[]>([]);

  constructor(private http: HttpClient) {}

  fetchUsers(): void {
    this.http.get<User[]>(this.apiUrl).subscribe(
      users => this.users$.next(users),
      error => console.error('Fetch Error', error)
    );
  }

  getUsers(): Observable<User[]> {
    return this.users$.asObservable();
  }

  createUser(user: User): Observable<User> {
    return this.http.post<User>(this.apiUrl, user).pipe(
      tap(newUser => this.users$.next([newUser, ...this.users$.getValue()])),
      catchError(this.handleError)
    );
  }

  updateUser(user: User): Observable<User> {
    return this.http.put<User>(`${this.apiUrl}/${user.id}`, user).pipe(
      tap(updatedUser => {
        const updatedList = this.users$.getValue().map(u => u.id === user.id ? updatedUser : u);
        this.users$.next(updatedList);
      }),
      catchError(this.handleError)
    );
  }

  deleteUser(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`).pipe(
      tap(() => {
        const updatedList = this.users$.getValue().filter(u => u.id !== id);
        this.users$.next(updatedList);
      }),
      catchError(this.handleError)
    );
  }

  getUserById(id: number): User | undefined {
    return this.users$.getValue().find(u => u.id === id);
  }

  private handleError(error: any) {
    return throwError(() => error);
  }
}
