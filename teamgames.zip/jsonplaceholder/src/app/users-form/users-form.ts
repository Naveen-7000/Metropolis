import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, ActivatedRoute, RouterModule } from '@angular/router';
import { FormBuilder, ReactiveFormsModule, Validators, FormGroup } from '@angular/forms';
import { UserService, User } from '../user';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-users-form',
  standalone: true,
  imports: [
    CommonModule, RouterModule, ReactiveFormsModule,
    MatCardModule, MatFormFieldModule, MatInputModule, MatButtonModule
  ],
  templateUrl: './users-form.html',
  styleUrls: ['./users-form.scss']
})
export class UsersFormComponent implements OnInit {
  userForm!: FormGroup;
  isEdit = false;
  userId?: number;
  successMsg = '';
  errorMsg = '';

  constructor(
    private fb: FormBuilder,
    private userService: UserService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit() {
    this.userId = Number(this.route.snapshot.paramMap.get('id'));
    this.isEdit = !!this.userId;
    let userData: User = { name: '', email: '', phone: '' };
    if (this.isEdit) {
      const user = this.userService.getUserById(this.userId!);
      if (user) userData = user;
    }
    this.userForm = this.fb.group({
      name: [userData.name, Validators.required],
      email: [userData.email, [Validators.required, Validators.email]],
      phone: [userData.phone, Validators.required]
    });
  }

  onSubmit() {
    if (this.userForm.invalid) return;
    const formValue: User = { ...this.userForm.value, id: this.userId };
    if (this.isEdit) {
      this.userService.updateUser(formValue).subscribe({
        next: () => {
          this.successMsg = 'User updated!';
          setTimeout(() => this.router.navigate(['/']), 800);
        },
        error: () => (this.errorMsg = 'Update failed!')
      });
    } else {
      this.userService.createUser(formValue).subscribe({
        next: () => {
          this.successMsg = 'User created!';
          setTimeout(() => this.router.navigate(['/']), 800);
        },
        error: () => (this.errorMsg = 'Creation failed!')
      });
    }
  }

  onCancel() {
    this.router.navigate(['/']);
  }
}
