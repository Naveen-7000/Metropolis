import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { UserService, User } from '../user';
import { MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';

@Component({
  selector: 'app-users-list',
  standalone: true,
  imports: [CommonModule, RouterModule, MatTableModule, MatIconModule, MatButtonModule, MatCardModule],
  templateUrl: './users-list.html',
  styleUrls: ['./users-list.scss']
})
export class UsersListComponent implements OnInit {
  users: User[] = [];
  loading = true;
  errorMsg = '';

  constructor(private userService: UserService, private router: Router) {}

  ngOnInit() {
    this.userService.fetchUsers();
    this.userService.getUsers().subscribe({
      next: data => { this.users = data; this.loading = false; },
      error: () => { this.errorMsg = 'Failed to load users'; this.loading = false; }
    });
  }

  onEdit(user: User) {
    this.router.navigate(['/edit', user.id]);
  }

  onDelete(user: User) {
    if (confirm(`Are you sure you want to delete ${user.name}?`)) {
      this.userService.deleteUser(user.id!).subscribe();
    }
  }

  onCreate() {
    this.router.navigate(['/create']);
  }
}
